public class FoxClientDemo {
    public static void main(String[] args) throws FoxException {
        String studentName = "";
        String studentSurname = "";
        long studentId = 0;
        String fileName = "";

        try{
            (new FoxClient()).connectToServer(studentName, studentSurname, studentId, fileName);
        }catch(FoxException e) {
            e.printStackTrace();
        }
    }
}
