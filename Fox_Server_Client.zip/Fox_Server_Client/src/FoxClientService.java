import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * FoxClientService is the class for handling incoming connections.
 * On failure, connection will be closed, main program will not be affected.
 * <P>
 * Implements method from: {@link java.lang.Runnable}.
 * <P>
 * Note: Class is not completed yet.
 */
public class FoxClientService implements Runnable {
    private Socket clientSocket;
    private InputStream in;
    private OutputStream out;

    public FoxClientService(Socket socket) {
        clientSocket = socket;
    }

    /**
     * Reads data from an incoming connection. If authorization succeeded for client,
     * creates a file related to incoming data, in case of file is already exists,
     * it will be overwritten. If authorization is failed, the connection will be closed.
     * <P>
     * New thread starts code execution on this method.
     */
    public void run() {
        try {
            String studentName;
            String studentSurname;
            long studentId;
            String fileName;
            
            in = clientSocket.getInputStream();
            
            while(in.available() < 4);
            
            byte[] header = new byte[4];
            in.read(header);
            int headerLength = fetchInt(header, 0, 4);
            byte[] data = new byte[headerLength];
            
            int index = 0;
            
            while(in.available() < headerLength);
            in.read(data);
            
            int studentNameLength = fetchInt(data, index, index + 4);
            index += 4;
            studentName = fetchString(data, index, index + studentNameLength);
            index += studentNameLength;

            int studentSurnameLength = ByteBuffer.wrap(Arrays.copyOfRange(data, index, index + 4)).getInt();
            index += 4;
            studentSurname = fetchString(data, index, index + studentSurnameLength);
            index += studentSurnameLength;

            studentId = fetchLong(data, index, index + 8);
            index += 8;

            int fileNameLength = fetchInt(data, index, index + 4);
            index += 4;
            fileName = fetchString(data, index, index + fileNameLength);
            index += fileNameLength;

            System.out.println("studentName: " + studentName);
            System.out.println("studentSurname: " + studentSurname);
            System.out.println("studentId: " + studentId);
            System.out.println("fileName: " + fileName);

            out = new FileOutputStream(fileName);
            int byteCount;
            data = new byte[1024];
            while((byteCount = in.read(data)) > 0 && !Thread.interrupted()) {
                out.write(data, 0, byteCount);
            }
            
            out.close();
            clientSocket.close();
        } catch (IOException ex0) {
            try {
                if(out != null)
                    out.close();
                if(clientSocket != null)
                    clientSocket.close();
            } catch (IOException ex1) {
                ex1.printStackTrace();
            }
            ex0.printStackTrace();
        }
    }

    private int fetchInt(byte[] data, int startIndex, int endIndex) {
        return ByteBuffer.wrap(Arrays.copyOfRange(data, startIndex, endIndex)).getInt();
    }

    private long fetchLong(byte[] data, int startIndex, int endIndex) {
        return ByteBuffer.wrap(Arrays.copyOfRange(data, startIndex, endIndex)).getLong();
    }

    private String fetchString(byte[] data, int startIndex, int endIndex) {
        byte[] temp = Arrays.copyOfRange(data, startIndex, endIndex);
        return new String(temp, Charset.forName("UTF-8"));
    }
}